// トヨタセールスAIアシスタント JavaScript

// DOM 読み込み完了後に実行
document.addEventListener('DOMContentLoaded', function() {
    // 初期設定
    initApp();
    setupEventListeners();
    
    // デモ用：ログイン状態を設定（実際の実装ではサーバーサイド認証が必要）
    if (localStorage.getItem('isLoggedIn') === 'true') {
        showMainApp();
        document.getElementById('user-name').textContent = localStorage.getItem('username') || 'ユーザー';
    }
    
    // APIキー設定の読み込み
    loadApiSettings();
});

/**
 * アプリケーションの初期設定
 */
function initApp() {
    // ファイル選択の表示更新
    const voiceFileInput = document.getElementById('voice-file');
    if (voiceFileInput) {
        voiceFileInput.addEventListener('change', function() {
            const fileNameElement = document.getElementById('selected-file-name');
            if (this.files.length > 0) {
                fileNameElement.textContent = this.files[0].name;
                document.getElementById('process-voice-btn').disabled = false;
            } else {
                fileNameElement.textContent = '選択されていません';
                document.getElementById('process-voice-btn').disabled = true;
            }
        });
    }
    
    // アコーディオン初期化
    initAccordions();
    
    // プロポーザルタブ初期化
    initProposalTabs();
    
    // 通知クローズボタン設定
    document.querySelector('.notification-close').addEventListener('click', function() {
        document.getElementById('notification').classList.add('hidden');
    });
    
    // パスワード表示切替ボタン設定
    const togglePasswordBtns = document.querySelectorAll('.toggle-password-btn');
    togglePasswordBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const targetId = this.getAttribute('data-target');
            const input = document.getElementById(targetId);
            if (input.type === 'password') {
                input.type = 'text';
                this.querySelector('i').classList.remove('fa-eye');
                this.querySelector('i').classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                this.querySelector('i').classList.remove('fa-eye-slash');
                this.querySelector('i').classList.add('fa-eye');
            }
        });
    });
}

/**
 * イベントリスナーのセットアップ
 */
function setupEventListeners() {
    // ログインフォーム送信
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }
    
    // ナビゲーションタブ切り替え
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(item => {
        item.addEventListener('click', function() {
            changeTab(this.getAttribute('data-tab'));
        });
    });
    
    // 設定ボタン
    const settingsBtn = document.getElementById('settings-btn');
    if (settingsBtn) {
        settingsBtn.addEventListener('click', function() {
            toggleModal('settings-modal', true);
        });
    }
    
    // モーダルを閉じるボタン
    const closeModalBtns = document.querySelectorAll('.close-modal-btn');
    closeModalBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const modalId = this.closest('.modal').id;
            toggleModal(modalId, false);
        });
    });
    
    // 提案内容生成ボタン
    const generateProposalBtn = document.getElementById('generate-proposal-btn');
    if (generateProposalBtn) {
        generateProposalBtn.addEventListener('click', handleGenerateProposal);
    }
    
    // セールストーク生成ボタン
    const generateSalesTalkBtn = document.getElementById('generate-salestalk-btn');
    if (generateSalesTalkBtn) {
        generateSalesTalkBtn.addEventListener('click', handleGenerateSalesTalk);
    }
    
    // 履歴に保存ボタン
    const saveProposalBtn = document.getElementById('save-proposal-btn');
    if (saveProposalBtn) {
        saveProposalBtn.addEventListener('click', handleSaveProposal);
    }
    
    // 履歴に保存ボタン（ロールプレイ画面）
    const saveHistoryBtn = document.getElementById('save-history-btn');
    if (saveHistoryBtn) {
        saveHistoryBtn.addEventListener('click', handleSaveProposal);
    }
    
    // 提案画面に戻るボタン
    const backToProposalBtn = document.getElementById('back-to-proposal-btn');
    if (backToProposalBtn) {
        backToProposalBtn.addEventListener('click', function() {
            changeTab('proposal');
        });
    }
    
    // セールス役ロールプレイボタン
    const salesRoleBtn = document.getElementById('sales-role-btn');
    if (salesRoleBtn) {
        salesRoleBtn.addEventListener('click', function() {
            const url = document.getElementById('sales-role-url')?.value || 'https://play.dify.ai/sales-role';
            window.open(url, '_blank');
        });
    }
    
    // 顧客役ロールプレイボタン
    const customerRoleBtn = document.getElementById('customer-role-btn');
    if (customerRoleBtn) {
        customerRoleBtn.addEventListener('click', function() {
            const url = document.getElementById('customer-role-url')?.value || 'https://play.dify.ai/customer-role';
            window.open(url, '_blank');
        });
    }
    
    // 質問送信ボタン
    const qaSubmitBtn = document.getElementById('qa-submit');
    if (qaSubmitBtn) {
        qaSubmitBtn.addEventListener('click', handleAskQuestion);
    }
    
    // 質問入力フィールドでのエンターキー対応
    const qaQuestion = document.getElementById('qa-question');
    if (qaQuestion) {
        qaQuestion.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                handleAskQuestion();
            }
        });
    }
    
    // ログアウトボタン
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', handleLogout);
    }
    
    // API設定フォーム送信
    const apiSettingsForm = document.getElementById('api-settings-form');
    if (apiSettingsForm) {
        apiSettingsForm.addEventListener('submit', handleSaveApiSettings);
    }
    
    // API接続テストボタン
    const testConnectionBtn = document.getElementById('test-connection-btn');
    if (testConnectionBtn) {
        testConnectionBtn.addEventListener('click', handleTestConnection);
    }
}

/**
 * アコーディオン機能の初期化
 */
function initAccordions() {
    const accordionHeaders = document.querySelectorAll('.qa-accordion-header');
    accordionHeaders.forEach(header => {
        header.addEventListener('click', function() {
            const content = this.nextElementSibling;
            const isActive = this.classList.contains('active');
            
            // アクティブ状態を切り替え
            this.classList.toggle('active');
            
            // コンテンツの表示切替
            if (isActive) {
                content.style.display = 'none';
                content.classList.remove('active');
            } else {
                content.style.display = 'flex';
                content.classList.add('active');
            }
        });
    });
}

/**
 * プロポーザルタブの初期化
 */
function initProposalTabs() {
    const tabs = document.querySelectorAll('.proposal-tab');
    if (tabs.length === 0) return;
    
    tabs.forEach(tab => {
        tab.addEventListener('click', function() {
            // 現在のアクティブタブを非アクティブにする
            document.querySelectorAll('.proposal-tab').forEach(t => {
                t.classList.remove('active');
            });
            
            // 現在のアクティブコンテンツを非アクティブにする
            document.querySelectorAll('.proposal-tab-content').forEach(c => {
                c.classList.remove('active');
            });
            
            // クリックされたタブをアクティブにする
            this.classList.add('active');
            
            // 対応するコンテンツをアクティブにする
            const tabId = this.getAttribute('data-tab');
            const tabContent = document.getElementById(tabId);
            if (tabContent) {
                tabContent.classList.add('active');
            }
        });
    });
}

/**
 * タブの切り替え処理
 * @param {string} tabId - 表示するタブのID
 */
function changeTab(tabId) {
    // ナビアイテムのアクティブ状態を更新
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
    });
    document.querySelector(`.nav-item[data-tab="${tabId}"]`).classList.add('active');
    
    // コンテンツセクションの表示を切り替え
    document.querySelectorAll('.content-section').forEach(section => {
        section.classList.remove('active');
    });
    document.getElementById(tabId).classList.add('active');
}

/**
 * モーダルの表示・非表示を切り替え
 * @param {string} modalId - モーダルのID
 * @param {boolean} show - 表示するかどうか
 */
function toggleModal(modalId, show) {
    const modal = document.getElementById(modalId);
    if (show) {
        modal.classList.remove('hidden');
    } else {
        modal.classList.add('hidden');
    }
}

/**
 * ローディングオーバーレイの表示・非表示を切り替え
 * @param {boolean} show - 表示するかどうか
 */
function toggleLoading(show) {
    const loadingOverlay = document.getElementById('loading-overlay');
    if (show) {
        loadingOverlay.classList.remove('hidden');
    } else {
        loadingOverlay.classList.add('hidden');
    }
}

/**
 * 通知を表示
 * @param {string} message - 通知メッセージ
 * @param {string} type - 通知タイプ（success, error, warning）
 */
function showNotification(message, type = 'success') {
    const notification = document.getElementById('notification');
    const iconElement = notification.querySelector('.notification-icon');
    const messageElement = notification.querySelector('.notification-message');
    
    // タイプに応じたアイコンを設定
    notification.className = 'notification ' + type;
    
    switch (type) {
        case 'success':
            iconElement.className = 'notification-icon fas fa-check-circle';
            break;
        case 'error':
            iconElement.className = 'notification-icon fas fa-exclamation-circle';
            break;
        case 'warning':
            iconElement.className = 'notification-icon fas fa-exclamation-triangle';
            break;
        default:
            iconElement.className = 'notification-icon fas fa-info-circle';
    }
    
    // メッセージを設定
    messageElement.textContent = message;
    
    // 通知を表示
    notification.classList.remove('hidden');
    
    // 3秒後に自動的に閉じる
    setTimeout(() => {
        notification.classList.add('hidden');
    }, 3000);
}

/**
 * ログイン処理
 * @param {Event} e - イベントオブジェクト
 */
function handleLogin(e) {
    e.preventDefault();
    
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    
    if (!username || !password) {
        showNotification('ユーザー名とパスワードを入力してください', 'error');
        return;
    }
    
    toggleLoading(true);
    
    // 実際の環境では、ここでサーバーに認証リクエストを送信
    // デモ用にタイマーで遅延を模倣
    setTimeout(() => {
        toggleLoading(false);
        
        // デモではどんな値でもログイン成功にする
        document.getElementById('login-container').classList.add('hidden');
        document.getElementById('app-container').classList.remove('hidden');
        document.getElementById('user-name').textContent = username;
        
        // フォームをリセット
        document.getElementById('login-form').reset();
        
        // ログイン状態を保存（実際の実装ではセッション管理が必要）
        localStorage.setItem('isLoggedIn', 'true');
        localStorage.setItem('username', username);
    }, 1000);
}

/**
 * ログアウト処理
 */
function handleLogout() {
    // 実際の環境では、ここでサーバーにログアウトリクエストを送信
    
    document.getElementById('app-container').classList.add('hidden');
    document.getElementById('login-container').classList.remove('hidden');
    
    // フォームをリセット
    document.getElementById('login-form').reset();
    
    // ログイン状態をクリア
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('username');
    
    showNotification('ログアウトしました', 'success');
}

/**
 * 音声ファイル処理
 */
function handleProcessVoice() {
    const fileInput = document.getElementById('voice-file');
    if (!fileInput.files.length) {
        showNotification('ファイルが選択されていません', 'error');
        return;
    }
    
    const progressStatus = document.querySelector('.processing-status');
    progressStatus.classList.remove('hidden');
    
    const progressBar = document.getElementById('processing-progress');
    const statusText = document.getElementById('processing-status');
    
    // 進行状況を更新する関数
    const updateProgress = (percent) => {
        progressBar.style.width = `${percent}%`;
        statusText.textContent = `${percent}%`;
    };
    
    // 処理開始
    updateProgress(0);
    
    // 疑似的な進行状況の更新（実際のAPIリクエストでは、進行状況に応じて更新）
    let progress = 0;
    const interval = setInterval(() => {
        progress += 5;
        updateProgress(progress);
        
        if (progress >= 100) {
            clearInterval(interval);
            
            // 処理完了後の擬似データ（実際はAPIからの応答を利用）
            const extractedText = "山田太郎様（35歳・男性）、家族構成は妻と子供2人（5歳・2歳）。現在は軽自動車を所有しており、家族でのドライブや買い物での使用が多い。子供の成長に伴い、より広い室内空間を求めている。予算は300万円前後で、燃費性能も重視している。";
            
            // テキストエリアに抽出した情報を設定
            document.getElementById('customer-details').value = extractedText;
            
            showNotification('音声ファイルの処理が完了しました', 'success');
        }
    }, 100);
}

/**
 * 提案内容生成処理
 */
function handleGenerateProposal() {
    const customerName = document.getElementById('customer-name').value;
    const customerType = document.querySelector('input[name="customer-type"]:checked').value;
    const customerDetails = document.getElementById('customer-details').value;
    
    if (!customerName) {
        showNotification('顧客名を入力してください', 'error');
        return;
    }
    
    if (!customerDetails) {
        showNotification('顧客情報詳細を入力してください', 'warning');
    }
    
    toggleLoading(true);
    
    // APIリクエストの準備
    const requestData = {
        customer_name: customerName,
        customer_type: customerType,
        customer_details: customerDetails
    };
    
    console.log('提案生成リクエストデータ:', requestData);
    
    // サーバーに提案生成リクエストを送信
    fetch('/api/proposals', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(requestData)
    })
    .then(response => {
        if (!response.ok) {
            return response.json().then(err => {
                throw new Error(err.error || '提案生成中にエラーが発生しました');
            });
        }
        return response.json();
    })
    .then(data => {
        // デバッグ：APIレスポンスの確認
        console.log('提案生成APIレスポンス:', data);
        
        // 提案データをグローバル変数に保存
        window.currentProposal = data;
        
        // 提案内容を画面に表示
        displayProposalData(data);
        
        // 提案内容画面に切り替え
        changeTab('proposal');
        
        toggleLoading(false);
        showNotification('提案内容の生成が完了しました', 'success');
    })
    .catch(error => {
        console.error('提案生成エラー:', error);
        toggleLoading(false);
        showNotification(error.message || '提案の生成中にエラーが発生しました', 'error');
    });
}

/**
 * 提案内容を画面に表示
 * @param {Object} data - 提案データ
 */
function displayProposalData(data) {
    console.log('元のAPIレスポンス:', data);
    
    // APIレスポンスから提案データを抽出
    let proposalData = data;
    
    // textフィールドにJSON文字列が含まれている場合はパースする
    if (data.text && typeof data.text === 'string' && data.text.includes('```json')) {
        try {
            // ```json と ``` の間の内容を抽出
            const jsonMatch = data.text.match(/```json\n([\s\S]*?)\n```/);
            if (jsonMatch && jsonMatch[1]) {
                const parsedData = JSON.parse(jsonMatch[1]);
                console.log('パース済み提案データ:', parsedData);
                proposalData = parsedData;
            }
        } catch (error) {
            console.error('JSON解析エラー:', error);
        }
    }
    
    // 新しいAPIレスポンス構造を検出
    const isNewFormat = proposalData.customer_summary && proposalData.car_proposal;
    console.log('新フォーマット判定:', isNewFormat);
    
    // 顧客情報サマリーを更新
    if (isNewFormat) {
        // 新しいフォーマット（Dify APIの新しいレスポンス構造）
        document.getElementById('summary-name').textContent = proposalData.customer_summary.name || '';
        document.getElementById('summary-type').textContent = proposalData.customer_summary.type || '';
        document.getElementById('summary-details').textContent = proposalData.customer_summary.details || '';
        
        // 車種タブ
        document.getElementById('car-model').textContent = proposalData.car_proposal.model || '未設定';
        document.getElementById('car-grade').textContent = proposalData.car_proposal.grade || '未設定';
        document.getElementById('car-price').textContent = proposalData.car_proposal.price ? 
            `${parseInt(proposalData.car_proposal.price.total).toLocaleString()}円〜` : '未設定';
        document.getElementById('car-reason').textContent = proposalData.car_proposal.reason || '未設定';
        
        // 支払方法タブ
        document.getElementById('payment-method').textContent = proposalData.payment_proposal.method || '未設定';
        document.getElementById('payment-monthly').textContent = proposalData.payment_proposal.monthly_payment ? 
            `${proposalData.payment_proposal.monthly_payment}円` : '未設定';
        document.getElementById('payment-downpayment').textContent = proposalData.car_proposal.price && proposalData.car_proposal.price.down_payment ? 
            `${parseInt(proposalData.car_proposal.price.down_payment).toLocaleString()}円` : '未設定';
        document.getElementById('payment-period').textContent = proposalData.payment_proposal.period || '未設定';
        document.getElementById('payment-bonus').textContent = proposalData.payment_proposal.bonus_payment || '未設定';
        document.getElementById('payment-residual').textContent = proposalData.car_proposal.price && proposalData.car_proposal.price.residual_value ? 
            `${parseInt(proposalData.car_proposal.price.residual_value).toLocaleString()}円` : '未設定';
        document.getElementById('payment-reason').textContent = proposalData.payment_proposal.reason || '未設定';
        
        // 購入時期タブ
        document.getElementById('recommended-timing').textContent = proposalData.timing && proposalData.timing.recommended_date ? 
            `${proposalData.timing.recommended_date}までの購入を推奨` : '未設定';
        document.getElementById('timing-period').textContent = proposalData.timing && proposalData.timing.recommended_date ? 
            `${proposalData.timing.recommended_date}まで` : '未設定';
        document.getElementById('timing-campaign').textContent = '下取り10%UPキャンペーン実施中';
        document.getElementById('timing-reason').textContent = proposalData.timing && proposalData.timing.reason ? 
            proposalData.timing.reason : '未設定';
        
        // 下取り条件タブ
        document.getElementById('tradein-car').textContent = proposalData.trade_in && proposalData.trade_in.current_model ? 
            proposalData.trade_in.current_model : '未設定';
        document.getElementById('tradein-price').textContent = proposalData.trade_in && proposalData.trade_in.estimated_value ? 
            proposalData.trade_in.estimated_value : '査定要確認';
        document.getElementById('tradein-campaign').textContent = '10%アップ';
        document.getElementById('tradein-final').textContent = '査定後にご提案';
        
        // 下取りの理由/詳細
        const tradeinDetails = document.getElementById('tradein-details');
        if (tradeinDetails) {
            if (proposalData.trade_in && proposalData.trade_in.reason) {
                const reasonItems = proposalData.trade_in.reason
                    .split(/。|\.|、/)
                    .filter(item => item.trim().length > 0)
                    .map(item => `<li>${item.trim()}</li>`)
                    .join('');
                
                tradeinDetails.innerHTML = `<ul>${reasonItems}</ul>`;
            } else {
                tradeinDetails.innerHTML = `
                    <ul>
                        <li>名義変更や廃車手続きの手間が不要</li>
                        <li>新車の頭金に充当可能</li>
                        <li>現在実施中の下取りキャンペーンで査定額アップ</li>
                    </ul>
                `;
            }
        }
        
        // よくある質問
        const faqContainer = document.getElementById('faq-items');
        faqContainer.innerHTML = '';
        
        if (proposalData.expected_qa && proposalData.expected_qa.length > 0) {
            proposalData.expected_qa.forEach((qa, index) => {
                const qaItem = document.createElement('div');
                qaItem.className = 'qa-accordion-item';
                qaItem.innerHTML = `
                    <div class="qa-accordion-header">
                        <span class="qa-badge">Q</span>
                        <p>${qa.question}</p>
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="qa-accordion-content">
                        <span class="qa-badge">A</span>
                        <p>${qa.answer}</p>
                    </div>
                `;
                faqContainer.appendChild(qaItem);
            });
            
            // アコーディオン機能を再初期化
            initAccordions();
        } else {
            faqContainer.innerHTML = '<p>よくある質問はありません</p>';
        }
        
        // 元の提案内容に提案IDを引き継ぎ
        window.currentProposal.id = data.id;
    } else {
        // 旧フォーマット（以前のレスポンス構造）
        document.getElementById('summary-name').textContent = data.customer_name || '';
        document.getElementById('summary-type').textContent = data.customer_type || '';
        document.getElementById('summary-details').textContent = data.customer_details || '';
        
        // 車種タブ
        document.getElementById('car-model').textContent = data.car_model || '未設定';
        document.getElementById('car-grade').textContent = data.grade || '未設定';
        document.getElementById('car-price').textContent = data.price || '未設定';
        document.getElementById('car-reason').textContent = data.car_reason || data.reasons?.car || '未設定';
        
        // 支払方法タブ
        document.getElementById('payment-method').textContent = data.payment_method || '未設定';
        document.getElementById('payment-monthly').textContent = data.payment_monthly || '未設定';
        document.getElementById('payment-downpayment').textContent = data.payment_downpayment || '未設定';
        document.getElementById('payment-period').textContent = data.payment_period || '未設定';
        document.getElementById('payment-bonus').textContent = data.payment_bonus || '未設定';
        document.getElementById('payment-residual').textContent = data.payment_residual || '未設定';
        document.getElementById('payment-reason').textContent = data.payment_reason || data.reasons?.payment || '未設定';
        
        // 購入時期タブ
        document.getElementById('recommended-timing').textContent = data.recommended_timing || '未設定';
        document.getElementById('timing-period').textContent = data.timing_period || '未設定';
        document.getElementById('timing-campaign').textContent = data.timing_campaign || '未設定';
        document.getElementById('timing-reason').textContent = data.timing_reason || data.reasons?.timing || '未設定';
        
        // 下取り条件タブ
        document.getElementById('tradein-car').textContent = data.tradein_car || '未設定';
        document.getElementById('tradein-price').textContent = data.tradein_price || '未設定';
        document.getElementById('tradein-campaign').textContent = data.tradein_campaign || '未設定';
        document.getElementById('tradein-final').textContent = data.tradein_final || '未設定';
        
        // 下取りの理由/詳細
        const tradeinDetails = document.getElementById('tradein-details');
        if (tradeinDetails) {
            if (data.reasons?.tradein) {
                tradeinDetails.innerHTML = `<ul><li>${data.reasons.tradein.replace(/、/g, '</li><li>')}</li></ul>`;
            } else {
                tradeinDetails.innerHTML = `
                    <ul>
                        <li>名義変更や廃車手続きの手間が不要</li>
                        <li>新車の頭金に充当可能</li>
                        <li>現在実施中の下取りキャンペーンで査定額アップ</li>
                    </ul>
                `;
            }
        }
        
        // よくある質問
        const faqContainer = document.getElementById('faq-items');
        faqContainer.innerHTML = '';
        
        if (data.predefined_questions && data.predefined_questions.length > 0) {
            data.predefined_questions.forEach((qa, index) => {
                const qaItem = document.createElement('div');
                qaItem.className = 'qa-accordion-item';
                qaItem.innerHTML = `
                    <div class="qa-accordion-header">
                        <span class="qa-badge">Q</span>
                        <p>${qa.question}</p>
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="qa-accordion-content">
                        <span class="qa-badge">A</span>
                        <p>${qa.answer}</p>
                    </div>
                `;
                faqContainer.appendChild(qaItem);
            });
            
            // アコーディオン機能を再初期化
            initAccordions();
        } else {
            faqContainer.innerHTML = '<p>よくある質問はありません</p>';
        }
    }
}

/**
 * 質問応答処理
 */
function handleAskQuestion() {
    const questionInput = document.getElementById('qa-question');
    const question = questionInput.value.trim();
    
    if (!question) {
        showNotification('質問を入力してください', 'warning');
        return;
    }
    
    // 現在の提案IDを取得
    const proposalId = window.currentProposal?.id;
    if (!proposalId) {
        showNotification('提案情報がありません。先に提案を生成してください。', 'error');
        return;
    }
    
    toggleLoading(true);
    
    // APIリクエストを送信
    fetch('/api/questions', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            proposal_id: proposalId,
            question: question
        })
    })
    .then(response => {
        if (!response.ok) {
            return response.json().then(err => {
                throw new Error(err.error || '質問応答中にエラーが発生しました');
            });
        }
        return response.json();
    })
    .then(data => {
        toggleLoading(false);
        console.log('質問応答レスポンス:', data);
        
        // 回答データを解析して抽出
        let displayQuestion = data.question || question;
        let displayAnswer = '';
        let answerSummary = '';
        let answerDetail = '';
        
        // まず、data.answerがあるか確認
        if (data.answer) {
            displayAnswer = data.answer;
            console.log('元の回答テキスト:', displayAnswer);
            
            // 回答がJSON形式の場合は解析を試みる
            if (typeof displayAnswer === 'string') {
                try {
                    // ```json ～ ``` の形式で囲まれたJSON
                    if (displayAnswer.includes('```json')) {
                        console.log('```json形式のJSONを検出');
                        const jsonMatch = displayAnswer.match(/```json\s*([\s\S]*?)\s*```/);
                        
                        if (jsonMatch && jsonMatch[1]) {
                            const jsonText = jsonMatch[1].trim();
                            console.log('抽出されたJSON文字列:', jsonText);
                            
                            try {
                                const parsedJson = JSON.parse(jsonText);
                                console.log('解析されたJSONオブジェクト:', parsedJson);
                                
                                // 特定のキーを持つJSONオブジェクトの場合
                                if (parsedJson['回答要約']) {
                                    answerSummary = parsedJson['回答要約'];
                                    console.log('回答要約を抽出:', answerSummary);
                                }
                                
                                if (parsedJson['詳細説明']) {
                                    answerDetail = parsedJson['詳細説明'];
                                    console.log('詳細説明を抽出:', answerDetail);
                                }
                                
                                // expected_qaから関連回答を抽出
                                if (!answerSummary && !answerDetail && parsedJson.expected_qa) {
                                    console.log('expected_qaからの回答抽出を試行');
                                    // 関連する質問を探す
                                    const relevantQA = parsedJson.expected_qa.find(qa => 
                                        qa.question.toLowerCase().includes(displayQuestion.toLowerCase()) || 
                                        displayQuestion.toLowerCase().includes(qa.question.toLowerCase())
                                    );
                                    
                                    if (relevantQA) {
                                        console.log('関連するQ&Aを発見:', relevantQA);
                                        answerSummary = "回答:";
                                        answerDetail = relevantQA.answer;
                                    } else if (parsedJson.expected_qa.length > 0) {
                                        // 関連質問が見つからなければ最初の回答を使用
                                        console.log('最初のQ&Aを使用');
                                        answerSummary = "関連する回答:";
                                        answerDetail = parsedJson.expected_qa[0].answer;
                                    }
                                }
                                
                                // それでも見つからなければ、JSONの内容を整形して表示
                                if (!answerSummary && !answerDetail) {
                                    console.log('JSON全体から回答を構築');
                                    answerSummary = "AIの回答:";
                                    const formattedDetails = [];
                                    
                                    // JSONの主要項目を抽出
                                    Object.keys(parsedJson).forEach(key => {
                                        if (typeof parsedJson[key] === 'string') {
                                            formattedDetails.push(`${key}: ${parsedJson[key]}`);
                                        } else if (typeof parsedJson[key] === 'object' && parsedJson[key] !== null) {
                                            if (Array.isArray(parsedJson[key])) {
                                                // 配列の場合は項目ごとに表示
                                                formattedDetails.push(`${key}:`);
                                                parsedJson[key].forEach((item, index) => {
                                                    if (typeof item === 'string') {
                                                        formattedDetails.push(`- ${item}`);
                                                    } else if (typeof item === 'object') {
                                                        // 配列内のオブジェクトの場合
                                                        formattedDetails.push(`- 項目${index + 1}: ${JSON.stringify(item)}`);
                                                    }
                                                });
                                            } else {
                                                // オブジェクトの場合はフラット化して表示
                                                const objDesc = Object.entries(parsedJson[key])
                                                    .map(([k, v]) => `${k}: ${typeof v === 'object' ? JSON.stringify(v) : v}`)
                                                    .join(', ');
                                                formattedDetails.push(`${key}: ${objDesc}`);
                                            }
                                        }
                                    });
                                    
                                    answerDetail = formattedDetails.join('<br>');
                                }
                            } catch (jsonError) {
                                console.error('JSON解析エラー:', jsonError);
                                // JSONの解析に失敗した場合
                                answerSummary = "AIの回答:";
                                // JSONブロックを削除して通常テキストとして表示
                                answerDetail = displayAnswer.replace(/```json[\s\S]*?```/g, '').trim();
                                if (!answerDetail) {
                                    answerDetail = displayAnswer; // 元のテキストを表示
                                }
                            }
                        } else {
                            // JSONブロックはあるが正しく抽出できない場合
                            console.log('JSONブロックの抽出に失敗');
                            answerSummary = "AIの回答:";
                            // JSONブロックを削除して通常テキストとして表示
                            answerDetail = displayAnswer.replace(/```json[\s\S]*?```/g, '').trim();
                            if (!answerDetail) {
                                answerDetail = displayAnswer; // 元のテキストを表示
                            }
                        }
                    } else if (displayAnswer.startsWith('{') && displayAnswer.endsWith('}')) {
                        // 直接JSONオブジェクトの形式の場合
                        console.log('直接JSONオブジェクト形式を検出');
                        try {
                            const parsedJson = JSON.parse(displayAnswer);
                            console.log('解析されたJSONオブジェクト:', parsedJson);
                            
                            if (parsedJson['回答要約']) {
                                answerSummary = parsedJson['回答要約'];
                            }
                            
                            if (parsedJson['詳細説明']) {
                                answerDetail = parsedJson['詳細説明'];
                            }
                            
                            // 回答が見つからない場合
                            if (!answerSummary && !answerDetail) {
                                answerSummary = "AIの回答:";
                                answerDetail = JSON.stringify(parsedJson, null, 2);
                            }
                        } catch (e) {
                            console.error('JSON解析エラー:', e);
                            // 無効なJSONの場合、そのままテキストとして表示
                            answerSummary = "AIの回答:";
                            answerDetail = displayAnswer;
                        }
                    } else {
                        // 通常のテキスト回答の場合
                        console.log('通常のテキスト回答を検出');
                        answerSummary = "AIの回答:";
                        answerDetail = displayAnswer;
                    }
                } catch (error) {
                    console.error('回答解析エラー:', error);
                    // 解析に失敗した場合は元のテキストをそのまま表示
                    answerSummary = "AIの回答:";
                    answerDetail = displayAnswer;
                }
            } else if (typeof displayAnswer === 'object' && displayAnswer !== null) {
                // 回答がすでにオブジェクトの場合
                console.log('回答がオブジェクト形式');
                answerSummary = "AIの回答:";
                answerDetail = JSON.stringify(displayAnswer, null, 2);
            }
        } else {
            // data.answerがない場合
            console.log('回答データが見つかりません');
            answerSummary = "AIの回答:";
            answerDetail = "申し訳ありませんが、回答を取得できませんでした。";
        }
        
        // 最後のフォールバック - いずれの方法でも回答が得られない場合
        if (!answerSummary && !answerDetail) {
            console.log('フォールバック: デフォルトの回答を使用');
            answerSummary = "AIの回答:";
            answerDetail = data.text || "申し訳ありませんが、回答を取得できませんでした。";
        }
        
        console.log('最終的な回答データ:', { summary: answerSummary, detail: answerDetail });
        
        // 回答を表示
        const qaResponsesContainer = document.getElementById('qa-responses');
        
        // コンテナが非表示の場合は表示する
        if (qaResponsesContainer.classList.contains('hidden')) {
            qaResponsesContainer.classList.remove('hidden');
        }
        
        const newQAItem = document.createElement('div');
        newQAItem.className = 'qa-item';
        
        // HTMLを構築
        newQAItem.innerHTML = `
            <div class="qa-question">
                <span class="qa-badge">Q</span>
                <p>${displayQuestion}</p>
            </div>
            <div class="qa-answer">
                <span class="qa-badge">A</span>
                <div>
                    ${answerSummary ? `<p class="answer-summary"><strong>${answerSummary}</strong></p>` : ''}
                    ${answerDetail ? `<p class="answer-detail">${answerDetail}</p>` : ''}
                </div>
            </div>
        `;
        
        // 新しい質問回答を先頭に追加
        qaResponsesContainer.prepend(newQAItem);
        
        // 入力フィールドをクリア
        questionInput.value = '';
    })
    .catch(error => {
        console.error('質問応答エラー:', error);
        toggleLoading(false);
        showNotification(error.message || '質問の処理中にエラーが発生しました', 'error');
    });
}

/**
 * セールストーク生成処理
 */
function handleGenerateSalesTalk() {
    // 現在の提案IDを取得
    const proposalId = window.currentProposal?.id;
    if (!proposalId) {
        showNotification('提案情報がありません。先に提案を生成してください。', 'error');
        return;
    }
    
    // 処理開始を通知
    toggleLoading(true);
    
    // APIリクエストを送信
    fetch('/api/salestalks', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            proposal_id: proposalId
        })
    })
    .then(response => {
        if (!response.ok) {
            return response.json().then(err => {
                throw new Error(err.error || 'セールストーク生成中にエラーが発生しました');
            });
        }
        return response.json();
    })
    .then(data => {
        toggleLoading(false);
        
        // サンプルセールストークをセット
        const salesTalkContent = document.getElementById('salestalk-content');
        
        // セールストークをパラグラフに分割して表示
        const paragraphs = data.content.trim().split('\n\n').filter(p => p.trim() !== '');
        
        let htmlContent = '';
        paragraphs.forEach(paragraph => {
            htmlContent += `<p>${paragraph}</p>`;
        });
        
        htmlContent += `
            <button id="copy-sales-talk" class="btn btn-text">
                <i class="fas fa-copy"></i> 全文コピー
            </button>
        `;
        
        salesTalkContent.innerHTML = htmlContent;
        
        // コピーボタンの機能を再設定
        document.getElementById('copy-sales-talk').addEventListener('click', function() {
            const text = Array.from(salesTalkContent.querySelectorAll('p'))
                .map(p => p.textContent)
                .join('\n\n');
            
            navigator.clipboard.writeText(text).then(() => {
                showNotification('セールストークをコピーしました', 'success');
            });
        });
        
        // ロールプレイ画面に遷移
        changeTab('roleplay');
        
        showNotification('セールストークを生成しました', 'success');
    })
    .catch(error => {
        console.error('セールストーク生成エラー:', error);
        toggleLoading(false);
        showNotification(error.message || 'セールストークの生成中にエラーが発生しました', 'error');
    });
}

/**
 * 提案を履歴に保存する処理
 */
function handleSaveProposal() {
    // 現在の提案IDを取得
    const proposalId = window.currentProposal?.id;
    if (!proposalId) {
        showNotification('提案情報がありません。先に提案を生成してください。', 'error');
        return;
    }
    
    toggleLoading(true);
    
    // APIリクエストを送信
    fetch(`/api/proposals/${proposalId}/save`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => {
        if (!response.ok) {
            return response.json().then(err => {
                throw new Error(err.error || '提案保存中にエラーが発生しました');
            });
        }
        return response.json();
    })
    .then(data => {
        toggleLoading(false);
        showNotification(data.message || '提案内容を履歴に保存しました', 'success');
    })
    .catch(error => {
        console.error('提案保存エラー:', error);
        toggleLoading(false);
        showNotification(error.message || '提案の保存中にエラーが発生しました', 'error');
    });
}

/**
 * メインアプリケーション表示
 */
function showMainApp() {
    document.getElementById('login-container').classList.add('hidden');
    document.getElementById('app-container').classList.remove('hidden');
}

/**
 * API設定の読み込み
 */
function loadApiSettings() {
    // サーバーからAPI設定を取得
    fetch('/api/config')
        .then(response => {
            if (!response.ok) {
                throw new Error('API設定の取得に失敗しました');
            }
            return response.json();
        })
        .then(data => {
            // フォームに値をセット
            document.getElementById('api-endpoint').value = data.endpoint_url || '';
            document.getElementById('api-key-proposal').value = data.api_key_proposal || '';
            document.getElementById('api-key-qa').value = data.api_key_qa || '';
            document.getElementById('api-key-salestalk').value = data.api_key_salestalk || '';
        })
        .catch(error => {
            console.error('API設定読み込みエラー:', error);
            // エラー時はデフォルト値または保存された値を使用
            const endpoint = localStorage.getItem('api_endpoint') || 'https://api.dify.ai/v1';
            document.getElementById('api-endpoint').value = endpoint;
        });
}

/**
 * API設定の保存処理
 * @param {Event} e - イベントオブジェクト
 */
function handleSaveApiSettings(e) {
    e.preventDefault();
    
    // フォームから値を取得
    const endpoint_url = document.getElementById('api-endpoint').value;
    const api_key_proposal = document.getElementById('api-key-proposal').value;
    const api_key_qa = document.getElementById('api-key-qa').value;
    const api_key_salestalk = document.getElementById('api-key-salestalk').value;
    
    // バリデーション
    if (!endpoint_url) {
        showNotification('APIエンドポイントを入力してください', 'error');
        return;
    }
    
    toggleLoading(true);
    
    // サーバーにAPI設定を送信
    fetch('/api/config/save', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            endpoint_url,
            api_key_proposal,
            api_key_qa,
            api_key_salestalk
        })
    })
    .then(response => {
        if (!response.ok) {
            return response.json().then(err => {
                throw new Error(err.message || 'API設定の保存に失敗しました');
            });
        }
        return response.json();
    })
    .then(data => {
        toggleLoading(false);
        
        // ローカルストレージにもバックアップ
        localStorage.setItem('api_endpoint', endpoint_url);
        
        // モーダルを閉じる
        toggleModal('settings-modal', false);
        
        showNotification(data.message || 'API設定を保存しました', 'success');
    })
    .catch(error => {
        console.error('API設定保存エラー:', error);
        toggleLoading(false);
        showNotification(error.message || 'API設定の保存中にエラーが発生しました', 'error');
    });
}

/**
 * API接続テスト処理
 */
function handleTestConnection() {
    // 接続状態をテスト中に変更
    const indicator = document.getElementById('connection-indicator');
    const statusText = document.getElementById('connection-status-text');
    const details = document.getElementById('connection-details');
    
    indicator.className = 'status-indicator';
    statusText.textContent = '接続テスト中...';
    details.textContent = '接続テストを実行しています。しばらくお待ちください。';
    
    // APIキーとエンドポイントを取得
    const endpoint = document.getElementById('api-endpoint').value;
    const keyProposal = document.getElementById('api-key-proposal').value;
    
    // バリデーション
    if (!endpoint || !keyProposal) {
        indicator.classList.add('error');
        statusText.textContent = 'エラー';
        details.textContent = 'APIエンドポイントとAPIキーを入力してください。';
        return;
    }
    
    // ストリーミングモードでテスト実行
    testApiConnection(endpoint, keyProposal, true);
}

/**
 * API接続テストを実行
 * @param {string} endpoint - APIエンドポイント
 * @param {string} apiKey - APIキー
 * @param {boolean} useStreaming - ストリーミングモードを使用するか
 */
function testApiConnection(endpoint, apiKey, useStreaming = true) {
    const indicator = document.getElementById('connection-indicator');
    const statusText = document.getElementById('connection-status-text');
    const details = document.getElementById('connection-details');
    
    // APIリクエストを送信
    fetch('/api/config/test', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            endpoint: endpoint,
            api_key: apiKey,
            test_type: 'proposal',
            use_streaming: useStreaming
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            indicator.classList.add('success');
            statusText.textContent = '接続成功';
            details.textContent = data.message || 'API接続テストに成功しました。';
        } else {
            // ストリーミングモードが失敗した場合、非ストリーミングモードでリトライ
            if (useStreaming) {
                console.log('ストリーミングモードでのテストに失敗。非ストリーミングモードでリトライします。');
                details.textContent = 'ストリーミングモードでの接続に失敗しました。通常モードでテスト中...';
                testApiConnection(endpoint, apiKey, false);
                return;
            }
            
            indicator.classList.add('error');
            statusText.textContent = '接続エラー';
            details.textContent = data.message || 'API接続テストに失敗しました。設定を確認してください。';
        }
    })
    .catch(error => {
        console.error('API接続テストエラー:', error);
        indicator.classList.add('error');
        statusText.textContent = '接続エラー';
        details.textContent = 'ネットワークエラーが発生しました。インターネット接続を確認してください。';
    });
} 