#!/bin/bash

# トヨタセールスAIアシスタント 起動スクリプト

# デフォルトポート
PORT=5001

# コマンドライン引数からポートを取得（指定がある場合）
if [ "$1" != "" ]; then
    PORT=$1
fi

echo "トヨタセールスAIアシスタントを起動しています..."
echo "使用ポート: $PORT"

# Flask環境変数を設定（開発環境向け）
export FLASK_ENV=development
export FLASK_DEBUG=1

# 単純に直接Pythonとapp.pyを実行
cd "$(dirname "$0")"
python -m flask run --host=0.0.0.0 --port=$PORT 