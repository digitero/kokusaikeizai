import requests
import json
import time
import sys

# APIの設定
base_url = "https://api.dify.ai/v1"
api_key = "app-A6BCdtQXwBsIeZILunfSo6yj"
headers = {
    "Authorization": f"Bearer {api_key}",
    "Content-Type": "application/json"
}

# リクエストデータ
customer_data = {
    "customer_name": "柴田 輝夫",
    "customer_type": "まだ購入意思なし（サービスで来店、たまたま来店など）",
    "dealer_info": "下取り10%アップキャンペーン（2025年9月まで）",
    "customer_details": "・年齢：51歳・性別：男性・家族構成：妻と子供2人・性格：まじめで慎重な性格。保守的。・職業：一部上場企業会社員・役職：課長・その他：現在マイカーを保有しており乗り換えには消極的だが6か月後に車検の予定がある。・現在の保有車両：トヨタ プリウス・ライフスタイル：アウトドア志向・価値観：安全性、快適性能、ブランド志向、アフターサービスなどの信頼性"
}

# ストリーミングモードで実行
def run_with_streaming():
    data = {
        "inputs": {
            "input": json.dumps(customer_data)
        },
        "response_mode": "streaming",
        "user": "user-123"
    }
    
    print("ストリーミングモードでリクエスト送信中...")
    try:
        with requests.post(f"{base_url}/workflows/run", headers=headers, json=data, stream=True) as response:
            if response.status_code == 200:
                final_output = {}
                for line in response.iter_lines():
                    if line:
                        # 'data: ' プレフィックスを削除
                        line_text = line.decode('utf-8')
                        if line_text.startswith("data: "):
                            json_str = line_text[6:]
                            try:
                                event_data = json.loads(json_str)
                                event_type = event_data.get("event")
                                
                                # 進行状況を表示
                                if event_type == "workflow_started":
                                    print("ワークフロー開始...")
                                elif event_type == "node_started":
                                    node_title = event_data.get("data", {}).get("title", "不明")
                                    print(f"ノード処理中: {node_title}")
                                elif event_type == "node_finished":
                                    node_title = event_data.get("data", {}).get("title", "不明")
                                    print(f"ノード完了: {node_title}")
                                elif event_type == "workflow_finished":
                                    print("ワークフロー完了")
                                    final_output = event_data.get("data", {}).get("outputs", {})
                                    break
                            except json.JSONDecodeError:
                                print(f"JSON解析エラー: {json_str}")
                
                # 最終結果を表示
                if final_output:
                    print("\n最終結果:")
                    print(json.dumps(final_output, indent=2, ensure_ascii=False))
                else:
                    print("最終結果が取得できませんでした")
            else:
                print(f"エラー: {response.status_code}")
                print(response.text)
    except requests.exceptions.RequestException as e:
        print(f"リクエスト例外: {e}")

# ブロッキングモードで実行（タイムアウトの可能性あり）
def run_with_blocking():
    data = {
        "inputs": {
            "input": json.dumps(customer_data)
        },
        "response_mode": "blocking",
        "user": "user-123"
    }
    
    print("ブロッキングモードでリクエスト送信中...")
    try:
        response = requests.post(f"{base_url}/workflows/run", headers=headers, json=data)
        if response.status_code == 200:
            result = response.json()
            print(json.dumps(result, indent=2, ensure_ascii=False))
        else:
            print(f"エラー: {response.status_code}")
            print(response.text)
    except requests.exceptions.RequestException as e:
        print(f"リクエスト例外: {e}")

if __name__ == "__main__":
    # ストリーミングモードを使用（推奨）
    run_with_streaming()
    
    # または、ブロッキングモードを使用（タイムアウトの可能性あり）
    # run_with_blocking() 