-- トヨタセールスAIアシスタント データベーススキーマ

-- 既存のテーブルがあれば削除
DROP TABLE IF EXISTS salestalks;
DROP TABLE IF EXISTS questions;
DROP TABLE IF EXISTS proposals;
DROP TABLE IF EXISTS api_config;
DROP TABLE IF EXISTS customers;

-- 顧客テーブル
CREATE TABLE customers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    details TEXT,
    customer_type TEXT,
    created_at TIMESTAMP NOT NULL,
    updated_at TIMESTAMP NOT NULL
);

-- API設定テーブル
CREATE TABLE api_config (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    api_key_proposal TEXT,
    api_key_qa TEXT,
    api_key_salestalk TEXT,
    endpoint_url TEXT,
    last_tested_at TIMESTAMP,
    updated_at TIMESTAMP NOT NULL
);

-- 提案テーブル
CREATE TABLE proposals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER NOT NULL,
    car_model TEXT,
    grade TEXT,
    payment_method TEXT,
    purchase_timing TEXT,
    trade_in_details TEXT,
    reasons_json TEXT,
    created_at TIMESTAMP NOT NULL,
    FOREIGN KEY (customer_id) REFERENCES customers (id)
);

-- 質問テーブル
CREATE TABLE questions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    proposal_id INTEGER NOT NULL,
    question_text TEXT NOT NULL,
    answer_text TEXT,
    is_predefined BOOLEAN NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL,
    FOREIGN KEY (proposal_id) REFERENCES proposals (id)
);

-- セールストークテーブル
CREATE TABLE salestalks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    proposal_id INTEGER NOT NULL,
    content TEXT,
    created_at TIMESTAMP NOT NULL,
    FOREIGN KEY (proposal_id) REFERENCES proposals (id)
);

-- インデックス作成
CREATE INDEX idx_customers_name ON customers (name);
CREATE INDEX idx_proposals_customer_id ON proposals (customer_id);
CREATE INDEX idx_questions_proposal_id ON questions (proposal_id);
CREATE INDEX idx_salestalks_proposal_id ON salestalks (proposal_id);

-- デフォルトのAPI設定を挿入
INSERT INTO api_config (api_key_proposal, api_key_qa, api_key_salestalk, endpoint_url, updated_at)
VALUES ('sk-proposal123456', 'sk-qa123456', 'sk-salestalk123456', 'https://api.dify.ai/v1/assistant', datetime('now')); 