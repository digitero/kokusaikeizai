#!/bin/bash

# トヨタセールスAIアシスタント セットアップスクリプト

echo "=========================================="
echo "トヨタセールスAIアシスタント セットアップを開始します"
echo "=========================================="

# 必要なライブラリをインストール
echo "1. 必要なライブラリをインストールしています..."
pip install -r requirements.txt

# .envファイルの作成（存在しない場合）
if [ ! -f .env ]; then
    echo "2. 環境変数ファイル(.env)を作成しています..."
    cat > .env << EOF
# トヨタセールスAIアシスタント環境変数

# Dify API設定 - 必要に応じて実際のAPIキーと設定に置き換えてください
DIFY_API_ENDPOINT=https://api.dify.ai/v1
DIFY_PROPOSAL_API_KEY=your_proposal_api_key_here
DIFY_QA_API_KEY=your_qa_api_key_here
DIFY_SALESTALK_API_KEY=your_salestalk_api_key_here
EOF
    echo
    echo "環境変数ファイル(.env)を作成しました。"
    echo "==> アプリケーションを本番環境で使用する場合は、.envファイルを編集して実際のAPIキーを設定してください。"
    echo "==> または、アプリケーション内の設定画面からAPIキーを設定することもできます。"
else
    echo "2. 環境変数ファイル(.env)が既に存在します。"
fi

# データベースの初期化
echo "3. データベースを初期化しています..."
python -c "from app import initialize_database; initialize_database()"

# API設定の説明
echo
echo "=========================================="
echo "APIキー設定方法の説明"
echo "=========================================="
echo "このアプリケーションはDify APIを使用しており、以下の方法でAPIキーを設定できます："
echo
echo "方法1: 環境変数(.env)ファイルで設定"
echo "   .envファイルを編集して以下のAPIキーを設定します："
echo "   - DIFY_PROPOSAL_API_KEY: 車種提案生成用APIキー"
echo "   - DIFY_QA_API_KEY: 質問応答用APIキー"
echo "   - DIFY_SALESTALK_API_KEY: セールストーク生成用APIキー"
echo
echo "方法2: アプリケーション内の設定画面で設定"
echo "   1. アプリケーションを起動して、画面右上の設定アイコンをクリック"
echo "   2. 各APIキーを入力して「設定を保存」をクリック"
echo "   3. 「接続テスト実行」で設定を検証（/infoエンドポイントを使用）"
echo
echo "注意: API接続テストでは、Dify APIの/infoエンドポイントを使用してアプリ情報を取得します。"
echo "      このエンドポイントにアクセス可能なAPIキーが必要です。"
echo
echo "=========================================="
echo "セットアップが完了しました。"
echo "アプリケーションを起動するには './run.sh' を実行してください。"
echo "デフォルトでは5001ポートが使用されます。"
echo "別のポートを指定するには './run.sh 5002' のように実行してください。"
echo "==========================================" 