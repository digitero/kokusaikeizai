#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import json
import uuid
import sqlite3
import requests
from datetime import datetime
from flask import Flask, request, jsonify, render_template, g, abort
from dotenv import load_dotenv

# 環境変数の読み込み
load_dotenv()

# Flaskアプリケーションの初期化
app = Flask(__name__)

# データベースファイルのパス
DATABASE = 'toyota_sales_assistant.db'

# デフォルトのDify API設定
DEFAULT_DIFY_API_ENDPOINT = os.getenv('DIFY_API_ENDPOINT', 'https://api.dify.ai/v1')
DEFAULT_PROPOSAL_API_KEY = os.getenv('DIFY_PROPOSAL_API_KEY', '')
DEFAULT_QA_API_KEY = os.getenv('DIFY_QA_API_KEY', '')
DEFAULT_SALESTALK_API_KEY = os.getenv('DIFY_SALESTALK_API_KEY', '')

# データベース接続
def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db

# データベース接続クローズ
@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

# データベースの初期化
def init_db():
    with app.app_context():
        db = get_db()
        with app.open_resource('schema.sql', mode='r') as f:
            db.cursor().executescript(f.read())
        db.commit()

# データベースが存在しない場合は初期化
def initialize_database():
    if not os.path.exists(DATABASE):
        with app.app_context():
            init_db()

# API設定を取得
def get_api_config():
    db = get_db()
    cursor = db.cursor()
    cursor.execute('SELECT * FROM api_config ORDER BY id DESC LIMIT 1')
    config = cursor.fetchone()
    
    if config:
        return {
            'endpoint_url': config['endpoint_url'] or DEFAULT_DIFY_API_ENDPOINT,
            'api_key_proposal': config['api_key_proposal'] or DEFAULT_PROPOSAL_API_KEY,
            'api_key_qa': config['api_key_qa'] or DEFAULT_QA_API_KEY,
            'api_key_salestalk': config['api_key_salestalk'] or DEFAULT_SALESTALK_API_KEY
        }
    else:
        return {
            'endpoint_url': DEFAULT_DIFY_API_ENDPOINT,
            'api_key_proposal': DEFAULT_PROPOSAL_API_KEY,
            'api_key_qa': DEFAULT_QA_API_KEY,
            'api_key_salestalk': DEFAULT_SALESTALK_API_KEY
        }

# Dify APIにリクエストを送信
def call_dify_api(api_type, data, use_streaming=True):
    config = get_api_config()
    
    # APIタイプに基づいてAPIキーとエンドポイントを選択
    if api_type == 'proposal':
        api_key = config['api_key_proposal']
    elif api_type == 'qa':
        api_key = config['api_key_qa']
    elif api_type == 'salestalk':
        api_key = config['api_key_salestalk']
    else:
        raise ValueError(f"Unknown API type: {api_type}")
    
    # ワークフローAPIのエンドポイント
    endpoint = f"{config['endpoint_url']}/workflows/run"
    
    # APIキーが設定されていない場合
    if not api_key:
        return {
            'error': True,
            'message': f"{api_type}用のAPIキーが設定されていません。設定画面でAPIキーを入力してください。"
        }
    
    # リクエストヘッダー
    headers = {
        'Authorization': f'Bearer {api_key}',
        'Content-Type': 'application/json'
    }
    
    # 入力内容をJSON文字列にラップ
    inputs = {}
    if data.get('inputs'):
        # 既存の入力がある場合はそのまま使用
        inputs = data.get('inputs')
    else:
        # 入力がない場合はクエリをINPUTとして使用
        customer_data = {
            'query': data.get('query', ''),
        }
        
        # コンテキストがあれば追加
        if data.get('context'):
            customer_data['context'] = data.get('context')
            
        # その他の重要なデータがあれば追加
        for key in ['customer_name', 'customer_type', 'customer_details', 'dealer_info']:
            if key in data:
                customer_data[key] = data[key]
                
        inputs = {"input": json.dumps(customer_data)}
    
    # ワークフローAPI用のリクエスト形式
    request_data = {
        "inputs": inputs,
        "response_mode": "streaming" if use_streaming else "blocking",
        "user": data.get('user', 'anonymous-user')
    }
    
    try:
        # ストリーミングの場合
        if use_streaming:
            app.logger.info(f"ストリーミングモードでDify APIリクエスト送信: {api_type}")
            
            response = requests.post(
                endpoint,
                headers=headers,
                json=request_data,
                stream=True
            )
            
            if response.status_code == 200:
                final_output = {}
                
                for line in response.iter_lines():
                    if line:
                        line_text = line.decode('utf-8')
                        if line_text.startswith("data: "):
                            json_str = line_text[6:]
                            try:
                                event_data = json.loads(json_str)
                                event_type = event_data.get("event")
                                
                                # 進行状況をログに出力
                                if event_type == "workflow_started":
                                    app.logger.info("ワークフロー開始...")
                                elif event_type == "node_started":
                                    node_title = event_data.get("data", {}).get("title", "不明")
                                    app.logger.info(f"ノード処理中: {node_title}")
                                elif event_type == "node_finished":
                                    node_title = event_data.get("data", {}).get("title", "不明")
                                    app.logger.info(f"ノード完了: {node_title}")
                                elif event_type == "workflow_finished":
                                    app.logger.info("ワークフロー完了")
                                    final_output = event_data.get("data", {}).get("outputs", {})
                                    break
                            except json.JSONDecodeError:
                                app.logger.error(f"JSON解析エラー: {json_str}")
                
                # 最終結果を戻り値にする
                if final_output:
                    app.logger.info(f"Dify APIレスポンス: {json.dumps(final_output, ensure_ascii=False)[:200]}...")
                    
                    # answer フィールドの抽出
                    answer = None
                    if 'answer' in final_output:
                        answer = final_output['answer']
                    else:
                        answer = json.dumps(final_output, ensure_ascii=False)
                    
                    return {'answer': answer}
                else:
                    return {
                        'error': True,
                        'message': '応答データが空でした。もう一度お試しください。'
                    }
            else:
                app.logger.error(f"Dify API Error: {response.status_code}, {response.text}")
                return {
                    'error': True,
                    'message': f"APIエラー({response.status_code}): {response.text}"
                }
        else:
            # ブロッキングモード（以前の実装）
            app.logger.info(f"ブロッキングモードでDify APIリクエスト送信: {api_type}")
            response = requests.post(endpoint, headers=headers, json=request_data, timeout=60)
            
            if response.status_code == 200:
                result = response.json()
                # ワークフローAPIからの応答を解析
                if 'outputs' in result:
                    # 結果をシンプルに返す
                    answer = None
                    
                    # 直接'answer'フィールドを探す
                    if 'answer' in result['outputs']:
                        answer = result['outputs']['answer']
                    # またはJSONレスポンス全体を返す
                    else:
                        answer = json.dumps(result['outputs'], ensure_ascii=False)
                    
                    return {'answer': answer}
                else:
                    return {
                        'error': True,
                        'message': '応答形式が正しくありません：' + json.dumps(result, ensure_ascii=False)
                    }
            else:
                app.logger.error(f"Dify API Error: {response.status_code}, {response.text}")
                return {
                    'error': True,
                    'message': f"APIエラー({response.status_code}): {response.text}"
                }
    except requests.exceptions.Timeout:
        return {
            'error': True,
            'message': "APIリクエストがタイムアウトしました。"
        }
    except requests.exceptions.ConnectionError:
        return {
            'error': True,
            'message': "APIサーバーに接続できませんでした。ネットワーク接続を確認してください。"
        }
    except Exception as e:
        app.logger.error(f"API Error: {str(e)}")
        return {
            'error': True,
            'message': f"APIエラー: {str(e)}"
        }

# メインページ
@app.route('/')
def index():
    return render_template('index.html')

# 顧客情報の登録
@app.route('/api/customers', methods=['POST'])
def create_customer():
    data = request.json
    
    if not data.get('name'):
        return jsonify({'error': '顧客名は必須です'}), 400
    
    db = get_db()
    cursor = db.cursor()
    
    try:
        cursor.execute(
            'INSERT INTO customers (name, details, customer_type, created_at, updated_at) VALUES (?, ?, ?, ?, ?)',
            (data.get('name'), data.get('details', ''), data.get('customer_type', ''), datetime.now(), datetime.now())
        )
        db.commit()
        
        customer_id = cursor.lastrowid
        return jsonify({
            'id': customer_id,
            'name': data.get('name'),
            'details': data.get('details', ''),
            'customer_type': data.get('customer_type', '')
        }), 201
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 500

# 提案内容の生成・保存
@app.route('/api/proposals', methods=['POST'])
def generate_proposal():
    data = request.json
    
    if not data.get('customer_name'):
        return jsonify({'error': '顧客名は必須です'}), 400
    
    # 顧客情報の取得または新規作成
    db = get_db()
    cursor = db.cursor()
    
    # 顧客情報を検索
    cursor.execute('SELECT id FROM customers WHERE name = ?', (data.get('customer_name'),))
    customer = cursor.fetchone()
    
    # 顧客情報が存在しない場合は新規作成
    if customer is None:
        cursor.execute(
            'INSERT INTO customers (name, details, customer_type, created_at, updated_at) VALUES (?, ?, ?, ?, ?)',
            (
                data.get('customer_name'),
                data.get('customer_details', ''),
                data.get('customer_type', ''),
                datetime.now(),
                datetime.now()
            )
        )
        db.commit()
        customer_id = cursor.lastrowid
    else:
        customer_id = customer['id']
    
    # Dify APIに送信するデータを準備
    customer_data = {
        "customer_name": data.get('customer_name'),
        "customer_type": data.get('customer_type', ''),
        "customer_details": data.get('customer_details', ''),
        "dealer_info": data.get('dealer_info', "下取り10%アップキャンペーン（2025年9月まで）")
    }
    
    # APIリクエストデータ
    api_data = {
        "inputs": {
            "input": json.dumps(customer_data)
        },
        "user": f"user_{customer_id}",
        "conversation_id": f"proposal_{uuid.uuid4()}"
    }
    
    # Dify APIを呼び出す（ストリーミングモードを使用）
    api_response = call_dify_api('proposal', api_data, use_streaming=True)
    
    # APIエラーの場合
    if api_response.get('error'):
        return jsonify({'error': api_response.get('message')}), 500
    
    try:
        # AIレスポンスから構造化データを抽出
        ai_response = api_response.get('answer', '')
        if not ai_response:
            # AIからの応答がない場合はモックデータを使用
            proposal_data = generate_mock_proposal(data)
        else:
            # AIの応答をパースして構造化データに変換
            try:
                # JSONレスポンスを期待する場合
                if '{' in ai_response and '}' in ai_response:
                    import re
                    json_match = re.search(r'({.*})', ai_response, re.DOTALL)
                    if json_match:
                        json_str = json_match.group(1)
                        parsed_data = json.loads(json_str)
                        proposal_data = parsed_data
                    else:
                        # JSON形式でなければモックデータを使用
                        proposal_data = generate_mock_proposal(data)
                else:
                    # テキスト応答を構造化（簡易実装）
                    proposal_data = {
                        'car_model': '不明（APIレスポンスの解析に失敗）',
                        'grade': '不明',
                        'price': '不明',
                        'car_reason': ai_response[:200] + '...',
                        'payment_method': '不明',
                        'payment_monthly': '不明',
                        'payment_reason': '不明',
                        'reasons': {
                            'car': '不明',
                            'payment': '不明',
                            'timing': '不明',
                            'tradein': '不明'
                        },
                        'predefined_questions': []
                    }
            except Exception as e:
                app.logger.error(f"JSON Parse Error: {str(e)}")
                # パースエラーの場合はモックデータを使用
                proposal_data = generate_mock_proposal(data)
        
        # 提案内容をデータベースに保存
        cursor.execute(
            '''
            INSERT INTO proposals 
            (customer_id, car_model, grade, payment_method, 
            purchase_timing, trade_in_details, reasons_json, created_at) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''',
            (
                customer_id,
                proposal_data.get('car_model', ''),
                proposal_data.get('grade', ''),
                proposal_data.get('payment_method', ''),
                proposal_data.get('timing_period', ''),
                proposal_data.get('tradein_car', ''),
                json.dumps(proposal_data.get('reasons', {})),
                datetime.now()
            )
        )
        db.commit()
        
        proposal_id = cursor.lastrowid
        
        # よくある質問をデータベースに保存
        for qa in proposal_data.get('predefined_questions', []):
            cursor.execute(
                'INSERT INTO questions (proposal_id, question_text, answer_text, is_predefined, created_at) VALUES (?, ?, ?, ?, ?)',
                (proposal_id, qa.get('question', ''), qa.get('answer', ''), True, datetime.now())
            )
        db.commit()
        
        # レスポンスデータを整形して返す
        response_data = {
            'id': proposal_id,
            'customer_id': customer_id,
            'customer_name': data.get('customer_name'),
            'customer_type': data.get('customer_type'),
            'customer_details': data.get('customer_details', ''),
            **proposal_data
        }
        return jsonify(response_data), 201
    except Exception as e:
        db.rollback()
        app.logger.error(f"Error saving proposal: {str(e)}")
        return jsonify({'error': str(e)}), 500

# 提案内容の取得
@app.route('/api/proposals/<int:proposal_id>', methods=['GET'])
def get_proposal(proposal_id):
    db = get_db()
    cursor = db.cursor()
    
    # 提案内容を取得
    cursor.execute(
        '''
        SELECT p.*, c.name as customer_name, c.details as customer_details, c.customer_type 
        FROM proposals p
        JOIN customers c ON p.customer_id = c.id
        WHERE p.id = ?
        ''',
        (proposal_id,)
    )
    proposal = cursor.fetchone()
    
    if not proposal:
        return jsonify({'error': '提案が見つかりません'}), 404
    
    # よくある質問を取得
    cursor.execute(
        'SELECT question_text, answer_text FROM questions WHERE proposal_id = ? AND is_predefined = 1',
        (proposal_id,)
    )
    questions = cursor.fetchall()
    
    # レスポンスデータを整形
    response_data = dict(proposal)
    response_data['reasons'] = json.loads(response_data['reasons_json'])
    del response_data['reasons_json']
    
    response_data['predefined_questions'] = [
        {'question': q['question_text'], 'answer': q['answer_text']} for q in questions
    ]
    
    return jsonify(response_data)

# 提案内容を履歴に保存
@app.route('/api/proposals/<int:proposal_id>/save', methods=['POST'])
def save_proposal(proposal_id):
    db = get_db()
    cursor = db.cursor()
    
    # 提案内容を確認
    cursor.execute('SELECT id FROM proposals WHERE id = ?', (proposal_id,))
    proposal = cursor.fetchone()
    
    if not proposal:
        return jsonify({'error': '提案が見つかりません'}), 404
    
    # 実際の実装では、保存フラグを更新するなどの処理を行う
    # ここではデモのため、成功レスポンスのみを返す
    return jsonify({'status': 'success', 'message': '提案を履歴に保存しました'})

# 質問応答の生成
@app.route('/api/questions', methods=['POST'])
def answer_question():
    data = request.json
    
    if not data.get('question'):
        return jsonify({'error': '質問は必須です'}), 400
    
    proposal_id = data.get('proposal_id')
    if not proposal_id:
        return jsonify({'error': '提案IDは必須です'}), 400
    
    # 提案内容を取得（コンテキスト用）
    db = get_db()
    cursor = db.cursor()
    cursor.execute(
        '''
        SELECT p.*, c.name as customer_name, c.details as customer_details, c.customer_type 
        FROM proposals p
        JOIN customers c ON p.customer_id = c.id
        WHERE p.id = ?
        ''',
        (proposal_id,)
    )
    proposal = cursor.fetchone()
    
    if not proposal:
        return jsonify({'error': '提案が見つかりません'}), 404
    
    # Dify APIに送信するデータを準備
    context = {
        "customer_name": proposal['customer_name'],
        "customer_details": proposal['customer_details'],
        "car_model": proposal['car_model'],
        "grade": proposal['grade'],
        "payment_method": proposal['payment_method'],
        "question": data.get('question')
    }
    
    # APIリクエストデータ
    api_data = {
        "inputs": {
            "input": json.dumps(context)
        },
        "user": f"user_{proposal['customer_id']}",
        "conversation_id": f"qa_{proposal_id}_{uuid.uuid4()}"
    }
    
    # Dify APIを呼び出す（ストリーミングモードを使用）
    api_response = call_dify_api('qa', api_data, use_streaming=True)
    
    # APIエラーの場合
    if api_response.get('error'):
        return jsonify({'error': api_response.get('message')}), 500
    
    # 回答を取得
    answer = api_response.get('answer', f"これはご質問「{data.get('question')}」に対するモック回答です。実際の実装ではDify APIからの回答が表示されます。")
    
    # 質問と回答をデータベースに保存
    try:
        cursor.execute(
            'INSERT INTO questions (proposal_id, question_text, answer_text, is_predefined, created_at) VALUES (?, ?, ?, ?, ?)',
            (proposal_id, data.get('question'), answer, False, datetime.now())
        )
        db.commit()
        
        question_id = cursor.lastrowid
        return jsonify({
            'id': question_id,
            'proposal_id': proposal_id,
            'question': data.get('question'),
            'answer': answer
        })
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 500

# セールストークの生成
@app.route('/api/salestalks', methods=['POST'])
def generate_salestalk():
    data = request.json
    
    proposal_id = data.get('proposal_id')
    if not proposal_id:
        return jsonify({'error': '提案IDは必須です'}), 400
    
    # 提案内容を取得
    db = get_db()
    cursor = db.cursor()
    cursor.execute(
        '''
        SELECT p.*, c.name as customer_name, c.details as customer_details, c.customer_type 
        FROM proposals p
        JOIN customers c ON p.customer_id = c.id
        WHERE p.id = ?
        ''',
        (proposal_id,)
    )
    proposal = cursor.fetchone()
    
    if not proposal:
        return jsonify({'error': '提案が見つかりません'}), 404
    
    # Dify APIに送信するデータを準備
    proposal_dict = dict(proposal)
    proposal_dict['reasons'] = json.loads(proposal['reasons_json'])
    
    # APIリクエストデータ
    api_data = {
        "inputs": {
            "input": json.dumps(proposal_dict)
        },
        "user": f"user_{proposal['customer_id']}",
        "conversation_id": f"salestalk_{proposal_id}_{uuid.uuid4()}"
    }
    
    # Dify APIを呼び出す（ストリーミングモードを使用）
    api_response = call_dify_api('salestalk', api_data, use_streaming=True)
    
    # APIエラーの場合
    if api_response.get('error'):
        # モックデータを生成
        customer_name = proposal['customer_name']
        car_model = proposal['car_model']
        
        salestalk_content = f"""
{customer_name}様、本日はお時間をいただきありがとうございます。

ご家族のライフスタイルとご要望を考慮して、{car_model}をご提案させていただきました。
特に以下の点が{customer_name}様のニーズに合致すると考えています：

1. 家族での使用に適した広い室内空間と3列シート
2. 燃費性能の良さと経済性に優れた運転性能
3. 長く使える実用性と子供の成長に合わせた多様なシートアレンジ

また、現在実施中の下取りキャンペーンと組み合わせることで、さらにお得にご購入いただけます。
残価設定型クレジットを活用すれば、月々の支払いを抑えながら新車に乗ることができます。

実際に{car_model}を見ていただければ、その魅力をより感じていただけると思います。試乗もご用意できますので、ぜひ実際の乗り心地を体験してみてください。

ご不明な点やご質問がございましたら、いつでもお気軽にお尋ねください。
{customer_name}様のカーライフを全力でサポートさせていただきます。
        """
    else:
        # API応答からセールストーク内容を取得
        salestalk_content = api_response.get('answer', '')
    
    # セールストークをデータベースに保存
    try:
        cursor.execute(
            'INSERT INTO salestalks (proposal_id, content, created_at) VALUES (?, ?, ?)',
            (proposal_id, salestalk_content, datetime.now())
        )
        db.commit()
        
        salestalk_id = cursor.lastrowid
        return jsonify({
            'id': salestalk_id,
            'proposal_id': proposal_id,
            'content': salestalk_content
        })
    except Exception as e:
        db.rollback()
        return jsonify({'error': str(e)}), 500

# API接続テスト
@app.route('/api/config/test', methods=['POST'])
def test_api_connection():
    data = request.json
    
    endpoint = data.get('endpoint')
    api_key = data.get('api_key')
    test_type = data.get('test_type', 'proposal')
    use_streaming = data.get('use_streaming', True)  # デフォルトでストリーミングモードを使用
    
    if not endpoint or not api_key:
        return jsonify({
            'status': 'error',
            'message': 'エンドポイントとAPIキーは必須です'
        }), 400
    
    try:
        # 簡単なテスト用データを作成
        test_input = {
            "customer_name": "テストユーザー",
            "customer_type": "テスト",
            "customer_details": "接続テスト用のデータです"
        }
        
        if use_streaming:
            # ストリーミング接続テスト - /workflows/run エンドポイントを使用
            response = requests.post(
                f"{endpoint}/workflows/run",
                headers={
                    'Authorization': f'Bearer {api_key}',
                    'Content-Type': 'application/json'
                },
                json={
                    "inputs": {"input": json.dumps(test_input)},
                    "response_mode": "streaming",
                    "user": f"test_user_{test_type}"
                },
                stream=True
            )
            
            if response.status_code == 200:
                # ストリーミング応答があればテスト成功
                success = False
                for line in response.iter_lines(timeout=10):
                    if line:
                        line_text = line.decode('utf-8')
                        if line_text.startswith("data: "):
                            success = True
                            break
                
                if success:
                    # テスト成功時にデータベースに設定を保存
                    save_api_config_to_db(endpoint, test_type, api_key)
                    
                    return jsonify({
                        'status': 'success',
                        'message': f'ストリーミングAPI接続テストに成功しました（{test_type}）'
                    })
                else:
                    return jsonify({
                        'status': 'error',
                        'message': 'ストリーミング応答を受信できませんでした'
                    })
            else:
                return jsonify({
                    'status': 'error',
                    'message': f'API接続テストに失敗しました。ステータスコード: {response.status_code}, レスポンス: {response.text}'
                })
        else:
            # 非ストリーミングテスト - /info エンドポイントを使用（シンプルなテスト）
            response = requests.get(
                f"{endpoint}/info",
                headers={
                    'Authorization': f'Bearer {api_key}',
                    'Content-Type': 'application/json'
                },
                timeout=15
            )
            
            if response.status_code == 200:
                # レスポンスの内容を確認
                result = response.json()
                app_name = result.get('name', 'Unknown App')
                
                # テスト成功時にデータベースに設定を保存
                save_api_config_to_db(endpoint, test_type, api_key)
                
                return jsonify({
                    'status': 'success',
                    'message': f'API接続テストに成功しました（{test_type}）。接続先アプリ: {app_name}'
                })
            else:
                return jsonify({
                    'status': 'error',
                    'message': f'API接続テストに失敗しました。ステータスコード: {response.status_code}, レスポンス: {response.text}'
                })
    except requests.exceptions.Timeout:
        return jsonify({
            'status': 'error',
            'message': 'API接続テストがタイムアウトしました。'
        })
    except requests.exceptions.ConnectionError:
        return jsonify({
            'status': 'error',
            'message': 'APIサーバーに接続できませんでした。ネットワーク接続を確認してください。'
        })
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': f'API接続テスト中にエラーが発生しました: {str(e)}'
        })

# API設定をデータベースに保存するヘルパー関数
def save_api_config_to_db(endpoint, test_type, api_key):
    db = get_db()
    cursor = db.cursor()
    
    # テスト成功時刻を記録
    cursor.execute(
        '''
        UPDATE api_config SET 
        endpoint_url = ?,
        api_key_proposal = CASE WHEN ? = 'proposal' THEN ? ELSE api_key_proposal END,
        api_key_qa = CASE WHEN ? = 'qa' THEN ? ELSE api_key_qa END,
        api_key_salestalk = CASE WHEN ? = 'salestalk' THEN ? ELSE api_key_salestalk END,
        last_tested_at = ?,
        updated_at = ?
        WHERE id = (SELECT id FROM api_config ORDER BY id DESC LIMIT 1)
        ''',
        (
            endpoint,
            test_type, api_key,
            test_type, api_key,
            test_type, api_key,
            datetime.now(),
            datetime.now()
        )
    )
    db.commit()
    
    # データベースから最新の設定を取得して.envファイルにも保存
    cursor.execute('SELECT * FROM api_config ORDER BY id DESC LIMIT 1')
    config = cursor.fetchone()
    if config:
        save_api_config_to_env_file(
            config['endpoint_url'],
            config['api_key_proposal'],
            config['api_key_qa'],
            config['api_key_salestalk']
        )

# API設定を.envファイルに保存（再起動時にも設定を保持するため）
def save_api_config_to_env_file(endpoint_url, api_key_proposal, api_key_qa, api_key_salestalk):
    try:
        # 現在の.envファイルの内容を読み込む
        env_path = '.env'
        env_content = {}
        
        if os.path.exists(env_path):
            with open(env_path, 'r', encoding='utf-8') as file:
                for line in file:
                    line = line.strip()
                    if line and not line.startswith('#') and '=' in line:
                        key, value = line.split('=', 1)
                        env_content[key.strip()] = value.strip()
        
        # API設定を更新
        env_content['DIFY_API_ENDPOINT'] = endpoint_url
        env_content['DIFY_PROPOSAL_API_KEY'] = api_key_proposal or ''
        env_content['DIFY_QA_API_KEY'] = api_key_qa or ''
        env_content['DIFY_SALESTALK_API_KEY'] = api_key_salestalk or ''
        
        # .envファイルに書き込む
        with open(env_path, 'w', encoding='utf-8') as file:
            file.write("# トヨタセールスAIアシスタント環境変数\n\n")
            file.write("# Dify API設定\n")
            for key, value in env_content.items():
                file.write(f"{key}={value}\n")
        
        return True
    except Exception as e:
        app.logger.error(f"Error saving API config to .env file: {str(e)}")
        return False

# API設定の保存
@app.route('/api/config/save', methods=['POST'])
def save_api_config():
    data = request.json
    
    endpoint_url = data.get('endpoint_url')
    api_key_proposal = data.get('api_key_proposal')
    api_key_qa = data.get('api_key_qa')
    api_key_salestalk = data.get('api_key_salestalk')
    
    if not endpoint_url:
        return jsonify({
            'status': 'error',
            'message': 'APIエンドポイントURLは必須です'
        }), 400
    
    db = get_db()
    cursor = db.cursor()
    
    try:
        # 設定レコードがあるか確認
        cursor.execute('SELECT COUNT(*) as count FROM api_config')
        count = cursor.fetchone()['count']
        
        if count > 0:
            # 既存の設定を更新
            cursor.execute(
                '''
                UPDATE api_config SET 
                endpoint_url = ?,
                api_key_proposal = ?,
                api_key_qa = ?,
                api_key_salestalk = ?,
                updated_at = ?
                WHERE id = (SELECT id FROM api_config ORDER BY id DESC LIMIT 1)
                ''',
                (
                    endpoint_url,
                    api_key_proposal,
                    api_key_qa,
                    api_key_salestalk,
                    datetime.now()
                )
            )
        else:
            # 新規レコードを作成
            cursor.execute(
                '''
                INSERT INTO api_config 
                (endpoint_url, api_key_proposal, api_key_qa, api_key_salestalk, updated_at)
                VALUES (?, ?, ?, ?, ?)
                ''',
                (
                    endpoint_url,
                    api_key_proposal,
                    api_key_qa,
                    api_key_salestalk,
                    datetime.now()
                )
            )
        
        db.commit()
        
        # 環境変数ファイル(.env)にも設定を保存（アプリ再起動時の保持のため）
        env_save_result = save_api_config_to_env_file(endpoint_url, api_key_proposal, api_key_qa, api_key_salestalk)
        
        return jsonify({
            'status': 'success',
            'message': 'API設定を保存しました' + ('' if env_save_result else '（注：環境変数ファイルへの保存に失敗しました）')
        })
    except Exception as e:
        db.rollback()
        app.logger.error(f"Error saving API config: {str(e)}")
        return jsonify({
            'status': 'error',
            'message': f'API設定の保存中にエラーが発生しました: {str(e)}'
        }), 500

# API設定の取得
@app.route('/api/config', methods=['GET'])
def get_api_config_endpoint():
    config = get_api_config()
    
    # APIキーはマスク処理して返す
    return jsonify({
        'endpoint_url': config['endpoint_url'],
        'api_key_proposal': mask_api_key(config['api_key_proposal']),
        'api_key_qa': mask_api_key(config['api_key_qa']),
        'api_key_salestalk': mask_api_key(config['api_key_salestalk'])
    })

# APIキーをマスク処理
def mask_api_key(api_key):
    if not api_key:
        return ''
    if len(api_key) <= 8:
        return '*' * len(api_key)
    return api_key[:4] + '*' * (len(api_key) - 8) + api_key[-4:]

# デモ用：モック提案データの生成
def generate_mock_proposal(customer_data):
    customer_type = customer_data.get('customer_type', '')
    customer_details = customer_data.get('customer_details', '')
    
    # 顧客タイプに基づいて車種を選定
    if 'purchase-intent-none' in customer_type:
        car_model = 'ヤリス'
        grade = 'Z（エントリーモデル）'
        price = '199万円～'
    elif 'purchase-comparison' in customer_type:
        car_model = 'RAV4'
        grade = 'G（スタンダードグレード）'
        price = '329万円～'
    else:
        car_model = 'シエンタ'
        grade = 'G（推奨）'
        price = '270万円～'
    
    # 子供がいる場合はファミリーカーを推奨
    if '子供' in customer_details or '家族' in customer_details:
        car_model = 'シエンタ'
        grade = 'G（推奨）'
        price = '270万円～'
    
    # アウトドア好きの場合はSUVを推奨
    if 'アウトドア' in customer_details or '趣味' in customer_details:
        car_model = 'RAV4'
        grade = 'アドベンチャー'
        price = '349万円～'
    
    # 環境意識が高い場合はハイブリッドを推奨
    payment_method = '残価設定型クレジット'
    if '環境' in customer_details or 'エコ' in customer_details:
        car_model += ' ハイブリッド'
        payment_method = 'カーリース（エコカーパック）'
    
    # モックデータを生成
    proposal = {
        'car_model': car_model,
        'grade': grade,
        'price': price,
        'car_reason': f'お客様のライフスタイルと予算に合わせて{car_model}をご提案します。{grade}は必要十分な装備を備えており、コストパフォーマンスに優れています。',
        
        'payment_method': payment_method,
        'payment_monthly': '35,000円',
        'payment_downpayment': '50万円',
        'payment_period': '60ヶ月（5年）',
        'payment_bonus': '年2回 各10万円',
        'payment_residual': '約110万円（車両価格の40％）',
        'payment_rate': '2.9％',
        'payment_reason': '月々の支払いを抑えながら新車に乗るメリットがあります。5年後には買取、返却、乗り換えを選択できる柔軟性があります。',
        
        'recommended_timing': '3ヶ月以内の購入を推奨',
        'timing_period': '2025年7月まで',
        'timing_campaign': '夏の買替応援キャンペーン実施中',
        'timing_reason': '現在実施中のキャンペーンにより、下取り価格の上乗せや金利優遇が適用され、最もお得に購入できる時期です。',
        
        'tradein_car': 'スズキ ワゴンR（2015年式）',
        'tradein_price': '約45万円',
        'tradein_campaign': '+5万円',
        'tradein_final': '220万円〜',
        
        'reasons': {
            'car': '家族4人での使用に適した3列シート、子供の成長に合わせて長く使える実用性、燃費性能の良さと経済性を考慮して選定しました。',
            'payment': '子供の教育費増加を見据えた家計計画、5年後の買い替えニーズに対応、月々の支払いを抑えながら新車に乗れるメリットがあります。',
            'timing': '現在実施中のキャンペーンにより、下取り価格の上乗せや金利優遇が適用され、最もお得に購入できる時期です。',
            'tradein': '名義変更や廃車手続きの手間が不要、新車の頭金に充当可能、現在実施中の下取りキャンペーンで査定額アップ。'
        },
        
        'predefined_questions': [
            {
                'question': '維持費はどれくらいかかりますか？',
                'answer': f'{car_model}は燃費が良く、年間の維持費は同クラスの中でも経済的です。燃費は約20km/Lですので、年間走行距離10,000kmの場合、燃料費は約7万円程度です。また、定期点検や保険なども含めると年間15〜20万円程度を目安にしていただくと良いでしょう。'
            },
            {
                'question': '子供が大きくなっても使えますか？',
                'answer': 'はい、3列目シートは十分な広さがあり、お子様が小学生、中学生になっても快適にお使いいただけます。また、シートアレンジも豊富で、お子様の成長に合わせて荷物が増えた場合にも対応できる実用性の高さが特徴です。'
            },
            {
                'question': '他のグレードとの違いは何ですか？',
                'answer': f'{grade}は基本的な安全装備と快適装備をバランス良く備えています。上位グレードでは、より高度な安全支援システムやプレミアムなオーディオ、本革シートなどが追加されますが、コストパフォーマンスを重視する場合は現在ご提案しているグレードがおすすめです。'
            }
        ]
    }
    
    return proposal

# データベースの初期化とアプリケーションの起動
if __name__ == '__main__':
    initialize_database()
    app.run(debug=True, host='0.0.0.0', port=5001) 