import requests
import json
import time
import sys

# APIの設定
base_url = "https://api.dify.ai/v1"
api_key = "app-GpbE4VKO2lUDHl5YlFWB2x26"  # 質問回答用の新しいAPIキー
headers = {
    "Authorization": f"Bearer {api_key}",
    "Content-Type": "application/json"
}

# リクエストデータ
customer_qa_data = {
    "customer_name": "山田 太郎",
    "customer_details": "年齢：45歳、性別：男性、家族構成：妻と子供2人、職業：IT企業管理職、現在所有車両：トヨタ カローラ（2018年式）、ライフスタイル：週末に家族でドライブ、価値観：安全性・燃費重視",
    "customer_type": "まだ購入意思なし（サービス来店）",
    "dealer_info": "下取り20%アップキャンペーン（2025年6月末まで）、期間限定特別金利0.9%適用",
    "sales_question": "この金利キャンペーンは全期間固定ですか？変動金利への切替は可能でしょうか？"
}

# ストリーミングモードで実行
def run_with_streaming():
    data = {
        "inputs": {
            "input": json.dumps(customer_qa_data)  # 質問を含む顧客データを渡す
        },
        "response_mode": "streaming",
        "user": "qa-user-123"  # QA用のユーザー識別子
    }
    
    print("ストリーミングモードでリクエスト送信中...")
    try:
        with requests.post(f"{base_url}/workflows/run", headers=headers, json=data, stream=True) as response:
            if response.status_code == 200:
                final_output = {}
                for line in response.iter_lines():
                    if line:
                        # 'data: ' プレフィックスを削除
                        line_text = line.decode('utf-8')
                        if line_text.startswith("data: "):
                            json_str = line_text[6:]
                            try:
                                event_data = json.loads(json_str)
                                event_type = event_data.get("event")
                                
                                # 進行状況を表示
                                if event_type == "workflow_started":
                                    print("Q&Aワークフロー開始...")
                                elif event_type == "node_started":
                                    node_title = event_data.get("data", {}).get("title", "不明")
                                    print(f"ノード処理中: {node_title}")
                                elif event_type == "node_finished":
                                    node_title = event_data.get("data", {}).get("title", "不明")
                                    print(f"ノード完了: {node_title}")
                                elif event_type == "workflow_finished":
                                    print("Q&Aワークフロー完了")
                                    final_output = event_data.get("data", {}).get("outputs", {})
                                    break
                            except json.JSONDecodeError:
                                print(f"JSON解析エラー: {json_str}")
                
                # 最終結果を表示（回答JSONを整形して表示）
                if final_output:
                    print("\n回答結果:")
                    # JSONから回答部分を抽出して表示
                    text_output = final_output.get("text", "{}")
                    try:
                        answer_json = json.loads(text_output)
                        print("【質問】")
                        print(answer_json.get("質問", "質問が見つかりません"))
                        print("\n【回答要約】")
                        print(answer_json.get("回答要約", "回答要約が見つかりません"))
                        print("\n【詳細説明】")
                        print(answer_json.get("詳細説明", "詳細説明が見つかりません"))
                    except json.JSONDecodeError:
                        # JSONでない場合はそのまま表示
                        print(text_output)
                else:
                    print("回答が取得できませんでした")
            else:
                print(f"エラー: {response.status_code}")
                print(response.text)
    except requests.exceptions.RequestException as e:
        print(f"リクエスト例外: {e}")

# ブロッキングモードで実行（タイムアウトの可能性あり）
def run_with_blocking():
    data = {
        "inputs": {
            "input": json.dumps(customer_qa_data)
        },
        "response_mode": "blocking",
        "user": "qa-user-123"
    }
    
    print("ブロッキングモードでリクエスト送信中...")
    try:
        response = requests.post(f"{base_url}/workflows/run", headers=headers, json=data)
        if response.status_code == 200:
            result = response.json()
            # データから回答部分を取り出して表示
            try:
                text_output = result.get("data", {}).get("outputs", {}).get("text", "{}")
                answer_json = json.loads(text_output)
                print("【質問】")
                print(answer_json.get("質問", "質問が見つかりません"))
                print("\n【回答要約】")
                print(answer_json.get("回答要約", "回答要約が見つかりません"))
                print("\n【詳細説明】")
                print(answer_json.get("詳細説明", "詳細説明が見つかりません"))
            except (json.JSONDecodeError, AttributeError):
                # 解析できない場合は生のレスポンスを表示
                print(json.dumps(result, indent=2, ensure_ascii=False))
        else:
            print(f"エラー: {response.status_code}")
            print(response.text)
    except requests.exceptions.RequestException as e:
        print(f"リクエスト例外: {e}")

if __name__ == "__main__":
    # ストリーミングモードを使用（推奨）
    run_with_streaming()
    
    # または、ブロッキングモードを使用（タイムアウトの可能性あり）
    # run_with_blocking()